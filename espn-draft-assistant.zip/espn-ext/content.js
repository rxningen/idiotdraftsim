/* Draft Room Assistant — reads a live ESPN draft and shows best available
   from your own half-PPR rankings.

   Detection strategy, most reliable first:
   1. ESPN's own fantasy API (same-origin from this page, so your login cookies
      are sent automatically — works for private leagues).
   2. DOM text scan of the draft board as a fallback if the API shape changes.
   Both are defensive: if one fails we fall back rather than breaking. */

(function () {
  'use strict';
  if (window.__draRan) return;
  window.__draRan = true;

  const IS_TOP = window === window.top;
  const MSG = 'DRA_FRAME_REPORT';

  // Child frames (ESPN sometimes renders the draft room in an iframe) don't draw
  // a panel — they scan their own document and post findings up to the top frame.
  function reportUp(payload) {
    try { window.top.postMessage({ type: MSG, payload }, '*'); } catch (e) {}
  }

  // ---------- name matching ----------
  const norm = (s) =>
    (s || '')
      .toLowerCase()
      .replace(/[.'’]/g, '')
      .replace(/\b(jr|sr|ii|iii|iv)\b/g, '')
      .replace(/[^a-z\s]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();

  const BY_NORM = new Map();
  RANKINGS.forEach((p) => BY_NORM.set(norm(p.n), p));

  // ESPN's roster panel abbreviates first names ("J. Hurts", "B. Thomas Jr.").
  // Index by "<first-initial> <lastname>" so those resolve too.
  const BY_ABBREV = new Map();
  RANKINGS.forEach((p) => {
    const parts = norm(p.n).split(' ').filter(Boolean);
    if (parts.length < 2) return;
    const key = parts[0][0] + ' ' + parts[parts.length - 1];
    if (!BY_ABBREV.has(key)) BY_ABBREV.set(key, []);
    BY_ABBREV.get(key).push(p);
  });
  // Team defenses: "Seattle D/ST" etc.
  function matchName(raw) {
    const k = norm(raw);
    if (BY_NORM.has(k)) return BY_NORM.get(k);
    const parts = k.split(' ').filter(Boolean);
    if (parts.length >= 2) {
      const ak = parts[0][0] + ' ' + parts[parts.length - 1];
      const cands = BY_ABBREV.get(ak);
      if (cands && cands.length === 1) return cands[0];
      if (cands && cands.length > 1) {
        // ambiguous initial+surname: prefer the best-ranked
        return cands.slice().sort((a, b) => a.r - b.r)[0];
      }
    }
    // D/ST forms
    const dst = k.replace(/\b(d ?st|dst|defense)\b/g, '').trim();
    if (dst) {
      const hit = RANKINGS.find(
        (p) => p.p === 'DST' && norm(p.n).includes(dst)
      );
      if (hit) return hit;
    }
    return null;
  }

  const drafted = new Set();   // normalized names
  let draftOrder = [];         // normalized names in actual pick order (when known)
  let orderKnown = false;      // true only when the API gave us pick numbers
  let boardSuspect = false;    // scan looks like it caught the available list
  let lastSource = 'none';
  let posFilter = '';

  // fetch with a timeout, and only send cookies when same-origin (cross-origin
  // credentialed requests fail CORS and surface as an opaque "Failed to fetch").
  async function safeFetch(url, extraHeaders) {
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 8000);
    try {
      const sameOrigin = url.startsWith(location.origin);
      const opts = {
        signal: ctrl.signal,
        credentials: sameOrigin ? 'include' : 'omit',
        headers: extraHeaders || {}
      };
      const res = await fetch(url, opts);
      if (!res.ok) return { ok: false, err: 'HTTP ' + res.status };
      return { ok: true, data: await res.json() };
    } catch (e) {
      return { ok: false, err: e.name === 'AbortError' ? 'timed out' : e.message };
    } finally {
      clearTimeout(timer);
    }
  }

  // ---------- strategy 1: ESPN fantasy API ----------
  function leagueIdFromUrl() {
    const m = location.search.match(/leagueId=(\d+)/);
    if (m) return m[1];
    const m2 = location.pathname.match(/leagueId[/=](\d+)/);
    return m2 ? m2[1] : null;
  }
  function seasonFromUrl() {
    const m = location.search.match(/seasonId=(\d+)/);
    return m ? m[1] : String(new Date().getFullYear());
  }

  let apiErr = '';
  async function tryApi() {
    apiErr = '';
    const leagueId = leagueIdFromUrl();
    if (!leagueId) return false;
    const season = seasonFromUrl();
    // Same-origin first. lm-api-reads is a DIFFERENT subdomain, so a credentialed
    // request there needs ESPN to return ACAO+ACAC for us — it usually doesn't,
    // which throws "Failed to fetch". Same-origin needs no CORS at all.
    const bases = [
      `https://fantasy.espn.com/apis/v3/games/ffl/seasons/${season}/segments/0/leagues/${leagueId}`,
      `https://lm-api-reads.fantasy.espn.com/apis/v3/games/ffl/seasons/${season}/segments/0/leagues/${leagueId}`
    ];
    for (const base of bases) {
      const r = await safeFetch(`${base}?view=mDraftDetail&view=mTeam&view=mRoster`);
      if (!r.ok) { apiErr = r.err; continue; }
      try {
        const data = r.data;
        const ids = new Set();

        const picks =
          (data.draftDetail && data.draftDetail.picks) || [];
        const ordered = picks
          .filter((p) => p && p.playerId)
          .sort((a, b) => (a.overallPickNumber || 0) - (b.overallPickNumber || 0));
        ordered.forEach((p) => ids.add(p.playerId));

        // rosters also reveal drafted players once assigned
        (data.teams || []).forEach((t) => {
          const entries =
            (t.roster && t.roster.entries) || [];
          entries.forEach((e) => {
            if (e && e.playerId) ids.add(e.playerId);
          });
        });

        if (!ids.size) continue;

        // resolve ids -> names
        const names = await resolveNames([...ids], season);
        if (!names.length) continue;
        drafted.clear();
        names.forEach((n) => {
          const k = norm(n);
          if (BY_NORM.has(k)) drafted.add(k);
        });
        // rebuild pick order from the ordered id list
        draftOrder = ordered
          .map((p) => nameCache.get(p.playerId))
          .filter(Boolean)
          .map(norm)
          .filter((k) => BY_NORM.has(k));
        orderKnown = draftOrder.length > 0;
        lastSource = 'ESPN API';
        return true;
      } catch (e) {
        apiErr = e.message;
      }
    }
    return false;
  }

  const nameCache = new Map();
  async function resolveNames(ids, season) {
    const unknown = ids.filter((i) => !nameCache.has(i));
    // Big filterIds arrays can 400; request in chunks.
    const CHUNK = 150;
    for (let i = 0; i < unknown.length; i += CHUNK) {
      const slice = unknown.slice(i, i + CHUNK);
      const filter = { players: { filterIds: { value: slice }, limit: slice.length } };
      const hdr = { 'x-fantasy-filter': JSON.stringify(filter) };
      const urls = [
        `${location.origin}/apis/v3/games/ffl/seasons/${season}/players?view=players_wl`,
        `https://lm-api-reads.fantasy.espn.com/apis/v3/games/ffl/seasons/${season}/players?view=players_wl`
      ];
      let got = false;
      for (const u of urls) {
        const r = await safeFetch(u, hdr);
        if (r.ok && Array.isArray(r.data)) {
          r.data.forEach((p) => {
            if (p && p.id && p.fullName) nameCache.set(p.id, p.fullName);
          });
          got = true;
          break;
        }
      }
      if (!got) break; // endpoint unavailable; fall back to DOM
    }
    return ids.map((i) => nameCache.get(i)).filter(Boolean);
  }

  // ---------- read the user's own roster panel ----------
  // ESPN renders a "Roster" table with POS / PLAYER / BYE columns.
  let myRoster = [];
  function readMyRoster() {
    const out = [];
    const tables = document.querySelectorAll('table');
    for (const t of tables) {
      const head = (t.innerText || '').slice(0, 120).toUpperCase();
      if (!/POS/.test(head) || !/PLAYER/.test(head)) continue;
      t.querySelectorAll('tr').forEach((tr) => {
        const cells = tr.querySelectorAll('td,th');
        if (cells.length < 2) return;
        const pos = (cells[0].innerText || '').trim().toUpperCase();
        if (!/^(QB|RB|WR|TE|FLEX|D\/ST|DST|K|BE|BN|IR)$/.test(pos)) return;
        let nameCell = (cells[1].innerText || '').trim();
        if (!nameCell || /^empty$/i.test(nameCell)) return;
        // strip trailing "(WR)" / "(QB)" annotations ESPN adds on bench rows
        nameCell = nameCell.replace(/\s*\([A-Z/]{1,4}\)\s*$/, '').trim();
        const hit = matchName(nameCell);
        if (hit) out.push(hit);
        else out.push({ n: nameCell, p: pos, t: '', r: 999, unmatched: true });
      });
      if (out.length) break;
    }
    myRoster = out;
    return out.length > 0;
  }

  // ---------- strategy 2: DOM text scan ----------
  function tryDom() {
    // Prefer a container that looks like the draft board / pick history.
    const sel = [
      '[class*="draft-board"]',
      '[class*="DraftBoard"]',
      '[class*="pick-history"]',
      '[class*="draft-column"]',
      '[class*="draftedPlayer"]'
    ].join(',');
    const scope = document.querySelector(sel);
    // Deliberately NO whole-page fallback: scanning the entire document also
    // matches the *available players* list, which produced exports containing
    // the whole ranking list. Better to report nothing than something wrong.
    if (!scope) return false;
    const text = scope.innerText;
    if (!text || text.length < 40) return false;
    const hay = ' ' + norm(text) + ' ';
    const hits = new Set();
    BY_NORM.forEach((p, key) => {
      if (key.length < 5) return; // avoid junk matches
      if (hay.includes(' ' + key + ' ')) hits.add(key);
    });
    if (!hits.size) return false;
    // Sanity check: a real draft board can't contain more players than the league
    // could possibly have taken. If we matched a huge share of the rankings, we
    // almost certainly scraped the *available players* list too — distrust it.
    const share = hits.size / RANKINGS.length;
    if (hits.size > 120 || share > 0.55) {
      boardSuspect = true;
      lastSource = 'board scan unreliable';
      drafted.clear();
      hits.forEach((h) => drafted.add(h));
      draftOrder = [...hits];
      orderKnown = false;
      return true;
    }
    boardSuspect = false;
    lastSource = 'draft board';
    drafted.clear();
    hits.forEach((h) => drafted.add(h));
    draftOrder = [...hits];
    orderKnown = false; // page scan can't tell us pick order
    return true;
  }

  // ---------- element picker ----------
  // Rather than guessing at ESPN's markup (which has burned us repeatedly), let
  // the user point at the available-players list once. We store a CSS path and
  // read that container from then on.
  let availSel = null;
  let autoDetected = false;
  let availPlayers = [];   // {name, matched:rankObj|null}

  function cssPath(el) {
    const parts = [];
    while (el && el.nodeType === 1 && parts.length < 6) {
      let seg = el.tagName.toLowerCase();
      if (el.id) { parts.unshift(seg + '#' + CSS.escape(el.id)); break; }
      const cls = (el.className || '').toString().trim().split(/\s+/)
        .filter((x) => x && !/^\d/.test(x)).slice(0, 2);
      if (cls.length) seg += '.' + cls.map((x) => CSS.escape(x)).join('.');
      const par = el.parentElement;
      if (par) {
        const sibs = [...par.children].filter((s) => s.tagName === el.tagName);
        if (sibs.length > 1) seg += ':nth-of-type(' + (sibs.indexOf(el) + 1) + ')';
      }
      parts.unshift(seg);
      el = el.parentElement;
    }
    return parts.join(' > ');
  }

  function startPicker() {
    const overlay = document.createElement('div');
    overlay.style.cssText =
      'position:fixed;inset:0;z-index:2147483646;cursor:crosshair;background:rgba(91,157,255,.06)';
    const hint = document.createElement('div');
    hint.textContent = 'Click ESPN\u2019s available-players list \u2014 Esc to cancel';
    hint.style.cssText =
      'position:fixed;top:12px;left:50%;transform:translateX(-50%);z-index:2147483647;' +
      'background:#12161d;color:#ffc94d;border:1px solid #ffc94d;border-radius:8px;' +
      'padding:8px 14px;font:600 13px system-ui;pointer-events:none';
    let marker = null;
    function hi(e) {
      overlay.style.pointerEvents = 'none';
      const el = document.elementFromPoint(e.clientX, e.clientY);
      overlay.style.pointerEvents = 'auto';
      if (!el || el.closest('#dra-panel')) return;
      if (marker) marker.style.outline = '';
      marker = el.closest('table, ul, [class*="list"], [class*="player"]') || el;
      marker.style.outline = '2px solid #ffc94d';
    }
    function done(e) {
      e.preventDefault(); e.stopPropagation();
      cleanup();
      if (!marker) return;
      autoDetected = false;
      availSel = cssPath(marker);
      try { chrome.storage.local.set({ availSel }); } catch (err) {}
      readAvailable();
      render();
    }
    function esc(e) { if (e.key === 'Escape') cleanup(); }
    function cleanup() {
      if (marker) marker.style.outline = '';
      overlay.remove(); hint.remove();
      document.removeEventListener('keydown', esc);
    }
    overlay.addEventListener('mousemove', hi);
    overlay.addEventListener('click', done, true);
    document.addEventListener('keydown', esc);
    document.body.appendChild(overlay);
    document.body.appendChild(hint);
  }

  // Auto-find ESPN's available-players list.
  // Signal: a container holding many ranked names but (almost) none of the
  // players already on my roster is the available list. The draft board and
  // pick history necessarily contain my drafted players, so they score badly.
  function autoDetectAvailable() {
    if (availSel || !myRoster.length) return false;
    const mineKeys = new Set(myRoster.map((p) => norm(p.n)));
    const cands = document.querySelectorAll(
      'table, ul, ol, [class*="list"], [class*="player"], [class*="Player"], [role="grid"], [role="table"]'
    );
    let best = null;
    for (const el of cands) {
      if (el.closest('#dra-panel')) continue;
      const txt = el.innerText || '';
      if (txt.length < 60 || txt.length > 200000) continue;
      const hay = ' ' + norm(txt) + ' ';
      let total = 0, mineHits = 0;
      BY_NORM.forEach((p, key) => {
        if (key.length < 5) return;
        if (hay.includes(' ' + key + ' ')) {
          total++;
          if (mineKeys.has(key)) mineHits++;
        }
      });
      if (total < 8) continue;
      // a good available list has lots of names and almost none of mine
      const mineRatio = mineHits / Math.max(1, mineKeys.size);
      const score = total * (1 - mineRatio) - mineHits * 12;
      if (mineRatio > 0.25) continue;              // contains my players -> it's the board
      if (!best || score > best.score) best = { el, score, total, mineHits };
    }
    if (!best) return false;
    availSel = cssPath(best.el);
    autoDetected = true;
    try { chrome.storage.local.set({ availSel }); } catch (e) {}
    return true;
  }

  // Read whatever ESPN is showing in the chosen container.
  function readAvailable() {
    availPlayers = [];
    if (!availSel) return false;
    let box = null;
    try { box = document.querySelector(availSel); } catch (e) { return false; }
    if (!box) return false;
    const rows = box.querySelectorAll('tr, li, [class*="row"]');
    const seen = new Set();
    const src = rows.length ? [...rows] : [box];
    src.forEach((r) => {
      const txt = (r.innerText || '').split('\n').map((s) => s.trim()).filter(Boolean);
      for (const t of txt) {
        if (t.length < 3 || t.length > 40) continue;
        if (!/[a-z]/i.test(t)) continue;
        const hit = matchName(t);
        const key = hit ? norm(hit.n) : norm(t);
        if (seen.has(key)) continue;
        // require it to look like a name (two words) or resolve in rankings
        if (!hit && t.split(/\s+/).length < 2) continue;
        seen.add(key);
        availPlayers.push({ name: hit ? hit.n : t, matched: hit || null });
        break; // one player per row
      }
    });
    return availPlayers.length > 0;
  }

  // ---------- panel ----------
  function ensurePanel() {
    if (!IS_TOP) return null;
    let el = document.getElementById('dra-panel');
    if (el && document.body.contains(el)) return el;
    return build();
  }

  function build() {
    const el = document.createElement('div');
    el.id = 'dra-panel';
    el.innerHTML = `
      <div id="dra-head">
        <b>Best Available</b>
        <button id="dra-refresh" title="Refresh now">↻</button>
        <button id="dra-toggle" title="Minimize">–</button>
      </div>
      <div id="dra-body">
        <div id="dra-status">Looking for your draft…</div>
        <div id="dra-filters"></div>
        <div id="dra-list"></div>
      </div>
      <div id="dra-foot">
        <button id="dra-copy">Copy my roster &rarr; simulator</button>
        <button id="dra-pick" style="margin-top:6px;background:#5b9dff;border-color:#5b9dff;color:#0a0e14;font-weight:600;">Set available list</button>
        <button id="dra-pool" style="margin-top:6px;">Copy ESPN pool &rarr; rankings</button>
        <button id="dra-diag" style="margin-top:6px;">Copy diagnostics</button>
      </div>`;
    document.body.appendChild(el);

    const head = el.querySelector('#dra-head');
    let dx = 0, dy = 0, dragging = false;
    head.addEventListener('mousedown', (e) => {
      if (e.target.tagName === 'BUTTON') return;
      dragging = true;
      dx = e.clientX - el.offsetLeft;
      dy = e.clientY - el.offsetTop;
      e.preventDefault();
    });
    document.addEventListener('mousemove', (e) => {
      if (!dragging) return;
      el.style.left = e.clientX - dx + 'px';
      el.style.top = e.clientY - dy + 'px';
      el.style.right = 'auto';
    });
    document.addEventListener('mouseup', () => (dragging = false));

    el.querySelector('#dra-toggle').addEventListener('click', () => {
      el.classList.toggle('dra-min');
      el.querySelector('#dra-toggle').textContent =
        el.classList.contains('dra-min') ? '+' : '–';
    });
    el.querySelector('#dra-refresh').addEventListener('click', refresh);
    el.querySelector('#dra-copy').addEventListener('click', () => {
      let out = '# Draft Room Assistant export\n';
      let summary = [];

      if (myRoster.length) {
        out += '## MY ROSTER\n';
        myRoster.forEach((p) => {
          out += 'MY: ' + p.n + (p.unmatched ? '   # not in rankings' : '') + '\n';
        });
        summary.push(myRoster.length + ' roster');
      }

      if (drafted.size && orderKnown && !boardSuspect) {
        out += '## ALL DRAFTED (in draft order)\n';
        draftOrder.forEach((k) => { const p = BY_NORM.get(k); if (p) out += p.n + '\n'; });
        summary.push(drafted.size + ' drafted');
      } else if (drafted.size) {
        // Order unknown or the scan looks contaminated: emit as comments so the
        // simulator's parser skips them. Importing them would rebuild a fake board.
        out += '# ALL DRAFTED omitted — ' +
          (boardSuspect
            ? 'the board scan also caught the available-players list'
            : 'pick order could not be determined') +
          ', so importing it would be wrong.\n';
        out += '# ' + drafted.size + ' names detected but not exported.\n';
      }

      if (!summary.length) out += '# nothing detected yet\n';
      navigator.clipboard.writeText(out);

      const s = el.querySelector('#dra-status');
      const prev = s.innerHTML;
      s.innerHTML = summary.length
        ? '<b>Copied ' + summary.join(' + ') + '.</b> Paste into the simulator&rsquo;s Live draft tab.'
        : '<b>Nothing to copy yet.</b>';
      setTimeout(() => (s.innerHTML = prev), 3200);
    });

    el.querySelector('#dra-pick').addEventListener('click', startPicker);
    el.querySelector('#dra-pool').addEventListener('click', () => {
      const s = el.querySelector('#dra-status');
      if (!availPlayers.length) {
        s.innerHTML = '<b>No player list set.</b> Click "Set available list" first.';
        return;
      }
      // Everything ESPN currently lists as available, plus everyone we know is
      // already drafted, becomes the pool. Ranks follow ESPN's own ordering.
      const seen = new Set();
      const rows = [];
      const push = (name, pos, team) => {
        const k = norm(name);
        if (seen.has(k)) return;
        seen.add(k);
        rows.push([name, pos || '', team || '']);
      };
      // drafted first (they were taken earliest), then ESPN's available order
      myRoster.forEach((p) => push(p.n, p.p, p.t));
      if (!boardSuspect) {
        (orderKnown ? draftOrder : [...drafted]).forEach((k) => {
          const p = BY_NORM.get(k); if (p) push(p.n, p.p, p.t);
        });
      }
      availPlayers.forEach((a) => {
        if (a.matched) push(a.matched.n, a.matched.p, a.matched.t);
        else push(a.name, '', '');
      });
      const out = rows.map((r, i) =>
        [i + 1, r[0], r[1] || 'WR', r[2] || '---'].join(', ')).join('\n');
      navigator.clipboard.writeText(out);
      const prev = s.innerHTML;
      s.innerHTML = '<b>Copied ' + rows.length + '-player pool.</b> Paste into the ' +
        'simulator&rsquo;s Player pool tab &rarr; Paste rankings.';
      setTimeout(() => (s.innerHTML = prev), 3500);
    });
    el.querySelector('#dra-diag').addEventListener('click', () => {
      const tables = [...document.querySelectorAll('table')].slice(0, 12).map((t, i) => {
        const head = (t.innerText || '').replace(/\s+/g, ' ').slice(0, 90);
        return '  table[' + i + ']: ' + head;
      });
      const boardSel = [
        '[class*="draft-board"]','[class*="DraftBoard"]','[class*="pick-history"]',
        '[class*="draft-column"]','[class*="draftedPlayer"]'
      ];
      const found = boardSel.filter((s) => document.querySelector(s));
      const d = [
        '=== Draft Room Assistant diagnostics ===',
        'url: ' + location.href.replace(/([?&](teamId|leagueId)=)\d+/g, '$1<redacted>'),
        'topFrame: ' + IS_TOP + ' | iframes on page: ' + document.querySelectorAll('iframe').length,
        'frameReportsReceived: ' + frameHits,
        'leagueId present: ' + !!leagueIdFromUrl(),
        'lastSource: ' + lastSource + ' | apiErr: ' + (apiErr || 'none'),
        'drafted detected: ' + drafted.size + ' | orderKnown: ' + orderKnown,
        'myRoster detected: ' + myRoster.length,
        'availSel: ' + (availSel || '(not set)'),
        'availPlayers read: ' + availPlayers.length,
        'roster names: ' + (myRoster.map((p) => p.n).join(', ') || '(none)'),
        'board selectors matched: ' + (found.join(', ') || '(none)'),
        'tables on page (' + document.querySelectorAll('table').length + '):',
        ...tables
      ].join('\n');
      navigator.clipboard.writeText(d);
      const s = el.querySelector('#dra-status');
      const prev = s.innerHTML;
      s.innerHTML = '<b>Diagnostics copied.</b> Paste them to get help.';
      setTimeout(() => (s.innerHTML = prev), 3000);
    });

    const filters = el.querySelector('#dra-filters');
    ['', 'QB', 'RB', 'WR', 'TE', 'K', 'DST'].forEach((p) => {
      const b = document.createElement('button');
      b.textContent = p || 'ALL';
      if (p === posFilter) b.classList.add('on');
      b.addEventListener('click', () => {
        posFilter = p;
        [...filters.children].forEach((c) => c.classList.remove('on'));
        b.classList.add('on');
        render();
      });
      filters.appendChild(b);
    });
    return el;
  }

  function render() {
    if (!IS_TOP) return;
    ensurePanel();
    const list = document.querySelector('#dra-list');
    const status = document.querySelector('#dra-status');
    if (!list || !status) return;
    // Preferred: show exactly what ESPN says is available, ordered by MY ranking.
    // Fallback: my rankings minus whatever we could detect as drafted.
    let avail, mode;
    if (availPlayers.length) {
      mode = 'espn';
      avail = availPlayers
        .map((a) => a.matched
          ? { ...a.matched, unranked: false }
          : { n: a.name, p: '', t: '', r: 9999, unranked: true })
        .filter((p) => !posFilter || p.p === posFilter)
        .sort((a, b) => a.r - b.r)
        .slice(0, 30);
    } else if (!boardSuspect && drafted.size) {
      // board scan looked sane — safe to subtract it
      mode = 'guess';
      avail = RANKINGS.filter(
        (p) => !drafted.has(norm(p.n)) && (!posFilter || p.p === posFilter)
      ).slice(0, 25);
    } else {
      // No trustworthy source. Showing "best available" here would list players
      // who are obviously long gone, which is worse than showing nothing.
      mode = 'unknown';
      avail = [];
    }

    status.className = '';
    if (mode === 'espn') {
      status.innerHTML =
        `<b>${availPlayers.length}</b> available, read from ESPN&rsquo;s list &mdash; ranked by yours.` +
        (autoDetected ? ' <span style="color:#5c6673">(auto-found)</span>' : '') +
        (myRoster.length ? `<br><b>${myRoster.length}</b> on your roster detected` : '');
    } else if (lastSource === 'none' && myRoster.length) {
      status.className = '';
      status.innerHTML =
        `<b>${myRoster.length}</b> players on your roster detected.` +
        ' For an accurate best-available list, click <b>Set available list</b>' +
        ' and then click ESPN&rsquo;s player list.';
    } else if (lastSource === 'none') {
      status.className = 'warn';
      const why = apiErr ? ` (API: ${apiErr})` : '';
      const noLeague = !leagueIdFromUrl()
        ? ' No leagueId in the URL — open the draft room from your league page.'
        : '';
      status.innerHTML =
        `<b>Not reading the draft yet.</b>${noLeague}${why} Retrying every ` +
        Math.round((failStreak === 0 ? 5000 : Math.min(60000, 5000 * Math.pow(2, failStreak))) / 1000) +
        's — or hit ↻.';
    } else {
      if (mode === 'unknown') {
        status.className = 'warn';
        status.innerHTML =
          (myRoster.length
            ? `<b>${myRoster.length}</b> on your roster detected — roster export works.`
            : '<b>Roster not found.</b>') +
          '<br>Available players unknown — set the list below to get real picks.';
      } else if (boardSuspect) {
        status.className = 'warn';
        status.innerHTML =
          (myRoster.length
            ? `<b>${myRoster.length}</b> on your roster detected — export works.`
            : '<b>Roster not found.</b>') +
          `<br>Board scan unreliable (matched ${drafted.size} names), so the full` +
          ' board is not exported.';
      } else {
        status.innerHTML =
          `<b>${drafted.size}</b> drafted &middot; source: ${lastSource}` +
          (myRoster.length ? `<br><b>${myRoster.length}</b> on your roster detected` : '');
      }
    }

    if (mode === 'unknown') {
      list.innerHTML =
        '<div style="padding:14px 4px;line-height:1.6;color:#8b95a3;font-size:12.5px;">' +
        "<b style=\"color:#ffc94d\">Can't tell who's available yet.</b><br>" +
        "ESPN's board markup isn't readable here, and guessing would list players " +
        'who are already drafted.<br><br>' +
        'Click <b>Set available list</b> below, then click ESPN&rsquo;s player list ' +
        'on the page. One-time setup.' +
        '</div>';
      return;
    }

    list.innerHTML =
      avail
        .map(
          (p) => `<div class="dra-row">
            <span class="dra-rank">${p.unranked ? '—' : p.r}</span>
            <span class="dra-name">${p.n}${p.unranked ? ' <em style="color:#5c6673;font-style:normal;font-size:11px">unranked</em>' : ''}</span>
            <span class="dra-team">${p.t || ''}</span>
            ${p.p ? `<span class="dra-pos dra-${p.p}">${p.p}</span>` : ''}
          </div>`
        )
        .join('') || '<div class="dra-row">No players match.</div>';
  }

  let failStreak = 0;
  let timer = null;
  let busy = false;
  let frameHits = 0;

  if (IS_TOP) {
    window.addEventListener('message', (e) => {
      const d = e.data;
      if (!d || d.type !== MSG || !d.payload) return;
      const p = d.payload;
      let changed = false;
      if (Array.isArray(p.roster) && p.roster.length > myRoster.length) {
        myRoster = p.roster
          .map((n) => matchName(n) || { n, p: '', t: '', r: 999, unmatched: true });
        changed = true;
      }
      if (Array.isArray(p.drafted) && p.drafted.length > drafted.size) {
        drafted.clear();
        p.drafted.forEach((n) => { const m = matchName(n); if (m) drafted.add(norm(m.n)); });
        lastSource = 'draft board (iframe)';
        changed = true;
      }
      if (changed) { frameHits++; try { render(); } catch (err) {} }
    });
  }

  async function refresh() {
    if (busy) return;
    busy = true;
    try {
      const rosterOk = readMyRoster();
      if (!availSel) autoDetectAvailable();
      readAvailable();
      const ok = await tryApi();
      if (!ok) {
        const domOk = tryDom();
        failStreak = (domOk || rosterOk) ? 0 : failStreak + 1;
      } else {
        failStreak = 0;
      }
    } catch (e) {
      failStreak++;
      apiErr = apiErr || e.message;
    } finally {
      busy = false;
      if (IS_TOP) {
        try { render(); } catch (e) { console.warn('[DRA] render failed:', e); }
      } else if (myRoster.length || drafted.size) {
        reportUp({
          roster: myRoster.map((p) => p.n),
          drafted: [...drafted].map((k) => (BY_NORM.get(k) || {}).n).filter(Boolean)
        });
      }
      schedule();
    }
  }

  // Back off when things are failing: 5s normally, up to 60s after repeated misses.
  function schedule() {
    clearTimeout(timer);
    const delay = failStreak === 0 ? 5000 : Math.min(60000, 5000 * Math.pow(2, failStreak));
    timer = setTimeout(refresh, delay);
  }

  // Don't poll a background tab.
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) { failStreak = 0; refresh(); }
  });

  window.addEventListener('unhandledrejection', (e) => {
    if (String(e.reason && e.reason.message || '').includes('fetch')) e.preventDefault();
  });

  if (IS_TOP) build();
  try {
    chrome.storage.local.get(['availSel'], (v) => {
      if (v && v.availSel) { availSel = v.availSel; readAvailable(); try { render(); } catch (e) {} }
    });
  } catch (e) {}
  refresh();
})();
