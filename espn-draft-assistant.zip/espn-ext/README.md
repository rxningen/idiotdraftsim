# Draft Room Assistant — Half-PPR

A Chrome/Edge extension that watches your live ESPN fantasy draft and shows the
best players still available, ranked by your own half-PPR list (the same 219-player
pool from the Draft Room simulator).

## Install (2 minutes, no store needed)

1. Unzip this folder somewhere permanent — if you delete it, the extension stops working.
2. Open `chrome://extensions` (or `edge://extensions`).
3. Turn on **Developer mode** (top-right toggle).
4. Click **Load unpacked** and select this folder.
5. Open your ESPN draft room. A panel appears in the top-right.

## First run: point it at ESPN's player list

The **best-available list is only accurate once you tell it where ESPN shows
available players.** Guessing at ESPN's markup proved unreliable, so:

1. Open your draft room.
2. In the panel, click **Set available list**.
3. Click ESPN's list of available players. A gold outline shows what you're about
   to select — pick the container holding the rows, not a single name.

That's it. The choice is saved, so you only do it once per browser. From then on
the panel shows exactly what ESPN says is available, ordered by *your* rankings,
with anything missing from your list marked `unranked`.

Without this step the panel falls back to guessing, which can list players who are
already gone. The status line always tells you which mode you're in.

## Using ESPN's list as your rankings pool

**Copy ESPN pool → rankings** exports every player ESPN currently knows about —
your roster, anyone detected as drafted, and everything still available — as
`Rank, Name, Position, Team` lines. Paste that into the simulator's
**Player pool → Paste rankings** box and the simulator's pool becomes ESPN's,
so nothing can ever be "missing from rankings" again.

Trade-off worth knowing: the order comes from ESPN's list, not a half-PPR
consensus, so re-check the ranks afterwards if the ordering matters to you.
Requires **Set available list** first.

## Using it

- The panel lists the top 25 available players, auto-refreshing every 5 seconds.
- Filter by position with the ALL / QB / RB / WR / TE / K / DST buttons.
- Drag the header to move it; `–` minimizes; `↻` forces a refresh.
- **Copy drafted list** exports two sections:
  - `## MY ROSTER` — your own team, read straight from ESPN's Roster panel.
    These lines are prefixed `MY:` and the simulator assigns them directly to
    your team, so your roster mirrors ESPN exactly. **This is the reliable part.**
  - `## ALL DRAFTED` — everyone detected as taken, in true draft order when the
    API supplied pick numbers. If order couldn't be determined the header says
    `ORDER UNKNOWN` — don't rely on it to rebuild the board.
- Paste the whole thing into the simulator's **Live draft → Import picks from a
  real draft** box. Re-copy and hit **Append** as the draft goes on.
- ESPN abbreviates roster names ("J. Hurts", "B. Thomas Jr.", "Seattle D/ST").
  Both the extension and the simulator resolve these automatically.

## How it reads the draft

Two methods, tried in order:

1. **ESPN's own fantasy API.** The script runs on the ESPN page, so your login
   cookies go along automatically — this works for private leagues, and it's the
   accurate path. The status line reads `source: ESPN API`.
2. **Reading the draft board on screen.** Used only if the API call fails.
   Status reads `source: draft board`.

If it can only scan the whole page, the status turns amber and says
`unscoped — may be inaccurate`, because a full-page scan can pick up names from
the *available players* list too. Treat that reading with suspicion.

## Honest limitations

- **I could not test this against a live ESPN draft room.** The logic and name
  matching are tested, but ESPN's live draft page is a moving target. Expect to
  need a tweak or two the first time you run it.
- **ESPN's fantasy API is undocumented** and can change without notice. If the
  API path breaks, the DOM fallback usually still works.
- **Name matching is text-based.** Suffixes and punctuation are handled
  (`Brian Thomas Jr.`, `Ja'Marr Chase`, `Amon-Ra St. Brown` all match), but a
  player ESPN spells differently than your rankings won't be detected as drafted.
- **This is a read-only aid.** It does not draft for you, click anything, or
  automate the draft — deliberately. Automating picks would likely violate
  ESPN's terms of service; reading your own league in your own browser is a far
  smaller ask, but it's your call.
- **Rankings are baked in** at install time. To update them, edit `rankings.js`
  and reload the extension from `chrome://extensions`.

## If the panel is blank or missing

Click **Copy diagnostics** in the panel footer and paste the result — it reports
the URL (with IDs redacted), whether this is the top frame, how many iframes are
on the page, which board selectors matched, and every table it can see. That's
usually enough to pinpoint the problem.

Things worth checking first:

- **Reload the draft room after installing.** Content scripts only attach on load.
- **ESPN sometimes renders the draft in an iframe.** The extension now injects into
  all frames: child frames scan and post their findings to the panel in the top
  frame. If the panel never appears at all, the top frame may not match the URL
  patterns in `manifest.json` — send the diagnostics and it can be widened.
- **Check for script errors.** Right-click → Inspect → Console, filter for `[DRA]`.

## Troubleshooting

| Problem | Try this |
| --- | --- |
| Panel never appears | Confirm the URL starts with `https://fantasy.espn.com/football/`, then reload. |
| "Could not read the draft yet" | Make sure you're in the actual draft room, then hit ↻. |
| Everyone shows as available | The API call failed and the board wasn't found — check the status line for which source it used. |
| Everyone shows as drafted | It's doing an unscoped page scan and catching the available-players list. |
| "Failed to fetch" in the status | Normal if you're not in a draft room yet; it retries with backoff. If it persists, check the URL has `leagueId=`. |
| Status shows `API: HTTP 401` | You're signed out of ESPN in this browser, or the league isn't yours. |

## Notes on the network layer

- Requests go to **`fantasy.espn.com` first** (same-origin, so your cookies work
  with no CORS involved). `lm-api-reads.fantasy.espn.com` is only a fallback and
  is called *without* credentials, because a credentialed cross-subdomain request
  fails CORS and shows up as an opaque "Failed to fetch".
- Every request has an 8-second timeout.
- Polling backs off on failure: 5s → 10s → 20s → 40s → 60s, resetting as soon as
  a read succeeds. It also pauses while the tab is in the background.
- The panel reports the actual reason (`timed out`, `HTTP 401`, `Failed to fetch`)
  instead of failing silently.

## Files

- `manifest.json` — extension config (Manifest V3)
- `content.js` — detection + panel
- `rankings.js` — your 219-player half-PPR pool
- `panel.css` — styling
